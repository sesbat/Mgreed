#include "Framework.h"
#include "GameScene.h"

GameScene::GameScene()
{
	LoadGameMap("map_data.bin");
}

GameScene::~GameScene()
{
	delete curMap;
}

void GameScene::Update()
{
	curMap->Update();
}

void GameScene::Render()
{
	curMap->Render();
}

void GameScene::PostRender()
{

}

void GameScene::LoadGameMap(const string& fileName)
{
	MapManager::Get()->LoadAllMaps(fileName);
	curMap = MapManager::Get()->GetSelectedMap();
	MapManager::Get()->InitPlayer();
}
