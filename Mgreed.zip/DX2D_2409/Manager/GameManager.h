#pragma once

class MapEditorScene;
class GameManager
{
public:
    GameManager();
    ~GameManager();

    void Update();

    void PreRender();
    void Render();

private:
    void Init();
};