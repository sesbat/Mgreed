#pragma once
#include "Framework.h"

struct SpriteData
{
	string name;
	int x, y;
	int width, height;
	float pivotX, pivotY;
};