#include "Framework.h"
#include "Player.h"

Player::Player()
{
	hpBar = new Slider(L"Textures/UI/HealthBarFront.png",
		L"Textures/UI/HealthBarBack.png");
	hpBar->SetPos(CENTER_X, SCREEN_HEIGHT - 100);
	hpBar->SetParent(this);
	pos = CENTER;
	CreateActions();
}

Player::~Player()
{
	delete hpBar;
}

void Player::Update()
{
	RigidbodyObject::Update();
	Move();
	Jump();
	Gravity();

	actions[curState]->Update();
}

void Player::Render()
{
	hpBar->Render();
	RigidbodyObject::Render();
	actions[curState]->Render();
}

void Player::Move()
{
	if (curState >= JUMP) return;

	bool isMove = false;

	isMove |= KEY->Press('D');
	isMove |= KEY->Press('A');

	isMove ? SetActionState(MOVE) : SetActionState(IDLE);
}

void Player::Jump()
{
	if (curState >= JUMP) return;

	isGround = false;
	if (KEY->Down('W') || KEY->Down(VK_SPACE))
		SetActionState(JUMP);
}

void Player::Attack()
{
}

void Player::Push()
{
}

void Player::Gravity()
{
	if(!isGround)
	RigidbodyObject::Gravity();
}

void Player::Land()
{
	SetActionState(IDLE);
}

void Player::SetActionState(ActionState state)
{
	if (curState == state)
		return;

	curState = state;
	actions[curState]->Start();
}

void Player::CheckCollisionTiles(const vector<vector<Tile*>>& tiles)
{
	Vector2 tileSize = { 16,16 };
	int gridX = static_cast<int>(pos.x / tileSize.x);
	int gridY = static_cast<int>(pos.y / tileSize.y);

	for (int y = gridY - 2; y <= gridY + 2; ++y)
	{
		for (int x = gridX - 2; x <= gridX + 2; ++x)
		{
			if (y < 0 || y >= tiles.size() || x < 0 || x >= tiles[0].size())
				continue;

			Tile* tile = tiles[y][x];

			if (!tile || tile->GetType() != Tile::COLLISION)
				return;

			Vector2 overlap;
			if (tile->IsCollision(this, &overlap))  
			{
				if (overlap.x < overlap.y)
				{
					if (globalPos.x > tile->GetGlobalPos().x)
					{
						Translate(Vector2::Right() * overlap.x);
						if (velocity.x < 0)
							velocity.x = 0;
					}
					else
					{
						Translate(Vector2::Left() * overlap.x);
						if (velocity.x > 0)
							velocity.x = 0;
					}
				}
				else
				{
					if (globalPos.y > tile->GetGlobalPos().y)
					{
						Translate(Vector2::Up() * overlap.y);
						velocity.y = 0;
						pos.y = tile->Top() + size.y/2;
						isGround = true;
					}
					else
					{
						Translate(Vector2::Down() * overlap.y);
						velocity.y = 0;
					}
				}
				break;
			}
		}
	}
}

void Player::CreateActions()
{
	actions[IDLE] = new Action("Textures/Dungreed/Character/Idle/", "Idle.xml", true, 1.0f);
	actions[MOVE] = new PlayerMove(this);
	actions[JUMP] = new PlayerJump(this);
}
