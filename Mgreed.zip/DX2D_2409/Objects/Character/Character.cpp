#include "Framework.h"

Character::Character()
{
}

Character::~Character()
{
}
