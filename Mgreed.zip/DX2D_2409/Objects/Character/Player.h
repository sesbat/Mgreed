#pragma once
#include "Framework.h"

class Player : public Character
{
private:
	enum ActionState
	{
		IDLE, MOVE, JUMP,
	};
public:
	Player();
	~Player();

	void Update();
	void Render();

	void Land();
	void CheckCollisionTiles(const vector<vector<Tile*>>& tiles);
	bool IsGround() { return isGround; }
private:
	void Move();
	void Jump();
	void Attack();
	void Push();
	void Gravity();
	void SetActionState(ActionState state);
	void CreateActions();
private:
	ActionState curState = IDLE;
	map<ActionState, Action*> actions;

	Inventory* inventory;
	Slider* hpBar;

	bool isGround = false;
};
