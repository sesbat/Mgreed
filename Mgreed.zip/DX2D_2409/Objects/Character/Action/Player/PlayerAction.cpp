#include "Framework.h"

PlayerAction::PlayerAction(Player* player)
	:player(player)
{
}
