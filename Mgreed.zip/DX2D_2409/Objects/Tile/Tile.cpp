#include "Framework.h"

Tile::Tile(wstring file)
	: ImageObject(file)
{
}

Tile::~Tile()
{
}

