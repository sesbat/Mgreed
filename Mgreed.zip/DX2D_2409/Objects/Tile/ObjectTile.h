#pragma once

class ObjectTile : public Tile
{
public:
	ObjectTile(wstring pilePath);
	~ObjectTile();

};
