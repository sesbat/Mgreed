#include "Framework.h"
#include "Room.h"

Room::Room(int width, int height, Quad* backGround)
    : width(width), height(height), backGround(backGround)
{
    editTiles.resize(height, vector<EditTile*>(width, nullptr));
    collisionTiles.resize(height, vector<Tile*>(width, nullptr));

    CreateTiles();
    EventManager::Get()->AddEvent("UpdateInstance", bind(&Room::UpdateInstanceData, this));

    backGround->SetPos(CENTER);
    backGround->UpdateWorld();
}

Room::~Room()
{
    for (int y = 0; y < height; ++y)
    {
        for (int x = 0; x < width; ++x)
        {
            if (editTiles[y][x])
                delete editTiles[y][x];
            if (collisionTiles[y][x])
                delete collisionTiles[y][x];
        }
    }
}

void Room::Update()
{
    for (int y = 0; y < height; ++y)
    {
        for (int x = 0; x < width; ++x)
        {
            if (editTiles[y][x])
                editTiles[y][x]->Update();
            if (collisionTiles[y][x])
                collisionTiles[y][x]->Update();
        }
    }
}

void Room::Render()
{
    if (backGround)
        backGround->Render();

    instanceBuffer->Set(1);

    quad->GetMaterial()->Set();
    quad->GetMesh()->SetMesh();

    deviceContext->DrawIndexedInstanced(6, width * height + 50, 0, 0, 0);

    for (int y = 0; y < height; ++y)
    {
        for (int x = 0; x < width; ++x)
        {
            if (editTiles[y][x])
                editTiles[y][x]->Render();
            if (collisionTiles[y][x])
                collisionTiles[y][x]->Render();
        }
    }
}

void Room::SetEditTile(int x, int y, Vector2 frame)
{
    if (x < 0 || x >= width || y < 0 || y >= height)
        return;

    if (!editTiles[y][x])
        return;

    editTiles[y][x]->SetInstanceData(frame);
    UpdateInstanceData();
}

void Room::SetCollisionTile(int x, int y, wstring file)
{
    if (x < 0 || x >= width || y < 0 || y >= height)
        return;

    if (collisionTiles[y][x])
    {
        if (collisionTiles[y][x]->GetImage()->GetMaterial()->GetTexture()->GetFile() == file)
            return;

        delete collisionTiles[y][x];
        collisionTiles[y][x] = nullptr;
    }
    collisionTiles[y][x] = new Tile(file);
    collisionTiles[y][x]->SetPos(tileSize * Vector2(x, y));
    collisionTiles[y][x]->SetParent(this);
    collisionTiles[y][x]->UpdateWorld();
}

void Room::Save(const string& filePath)
{
    ofstream fout(filePath, ios::binary);

    fout.write((char*)&width, sizeof(int));
    fout.write((char*)&height, sizeof(int));

    for (int y = 0; y < height; ++y)
    {
        for (int x = 0; x < width; ++x)
        {
            Vector2 curFrame = editTiles[y][x]->GetInstanceData()->curFrame;
            fout.write((char*)&curFrame, sizeof(Vector2));
        }
    }

    for (int y = 0; y < height; ++y)
    {
        for (int x = 0; x < width; ++x)
        {
            bool hasTile = collisionTiles[y][x] != nullptr;
            fout.write((char*)&hasTile, sizeof(bool));
            if (hasTile)
            {
                string textureFile = Utility::ToString(collisionTiles[y][x]->GetImage()->GetMaterial()->GetTexture()->GetFile());
                size_t length = textureFile.size();
                fout.write((char*)&length, sizeof(size_t));
                fout.write(textureFile.c_str(), length);
            }
        }
    }

    fout.close();
}

void Room::Load(const string& filePath)
{
    ifstream fin(filePath, ios::binary);

    int loadedWidth, loadedHeight;
    fin.read((char*)&loadedWidth, sizeof(int));
    fin.read((char*)&loadedHeight, sizeof(int));

    if (loadedWidth != width || loadedHeight != height)
    {
        cout << "Room size mismatch! Aborting load." << endl;
        return;
    }

    for (int y = 0; y < height; ++y)
    {
        for (int x = 0; x < width; ++x)
        {
            Vector2 curFrame;
            fin.read((char*)&curFrame, sizeof(Vector2));
            editTiles[y][x]->SetInstanceData(curFrame);
        }
    }

    for (int y = 0; y < height; ++y)
    {
        for (int x = 0; x < width; ++x)
        {
            bool hasTile;
            fin.read((char*)&hasTile, sizeof(bool));
            if (hasTile)
            {
                size_t length;
                fin.read((char*)&length, sizeof(size_t));
                string textureFile(length, '\0');
                fin.read(&textureFile[0], length);

                collisionTiles[y][x] = new Tile(Utility::ToWString(textureFile));
                collisionTiles[y][x]->SetParent(this);
                collisionTiles[y][x]->SetPos(tileSize * Vector2(x, y));
                collisionTiles[y][x]->UpdateWorld();
            }
        }
    }

    fin.close();
    UpdateInstanceData();
}

void Room::CreateTiles()
{
    Vector2 maxFrame = { 13, 8 };

    quad = new Quad(L"Textures/Tile/tiles.png", Vector2(),
        Vector2(1 / maxFrame));
    quad->GetMaterial()->SetShader(L"Shaders/Instancing.hlsl");

    tileSize = quad->GetSize();

    UINT size = width * height;

    instances.resize(size);
    editTiles.reserve(size);
    collisionTiles.reserve(size);
    for (int y = 0; y < height; y++)
    {
        for (int x = 0; x < width; x++)
        {
            int index = y * width + x;

            EditTile* editTile = new EditTile(tileSize, &instances[index]);
            editTile->SetPos(tileSize * Vector2(x, y));
            editTile->SetParent(this);
            editTile->UpdateWorld();
            instances[index].transform = XMMatrixTranspose(editTile->GetWorld());
            instances[index].curFrame = { 12, 6 };
            instances[index].maxFrame = maxFrame;
            
            editTiles[y][x] = editTile;
            collisionTiles[y][x] = nullptr;
        }
    }

    instanceBuffer = new VertexBuffer(instances.data(), sizeof(InstanceData), size);
}

void Room::UpdateInstanceData()
{
	instanceBuffer->Update(instances.data(), instances.size());
}
