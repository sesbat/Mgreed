#pragma once

class CollisionTile : public Tile
{
public:
	CollisionTile(wstring pilePath);
	~CollisionTile();
};
