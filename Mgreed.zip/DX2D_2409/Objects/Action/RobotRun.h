#pragma once

class RobotRun : public RobotMove
{
public:
    RobotRun(Robot* robot);
    ~RobotRun();
};