#pragma once

class BossDie : public BossAction
{
public:
	BossDie(Boss* boss);

	void Update();
};

