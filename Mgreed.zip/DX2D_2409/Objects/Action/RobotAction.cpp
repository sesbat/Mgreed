#include "Framework.h"

RobotAction::RobotAction(Robot* robot) : robot(robot)
{
}
